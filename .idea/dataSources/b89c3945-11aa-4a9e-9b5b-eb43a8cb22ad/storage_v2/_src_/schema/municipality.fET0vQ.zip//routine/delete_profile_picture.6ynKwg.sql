create
    definer = root@localhost procedure delete_profile_picture(IN superhero_id varchar(255), IN position int,
                                                              IN deleted_at varchar(255))
BEGIN

UPDATE profile_picture 
SET 
	profile_picture.deleted_at = deleted_at
WHERE profile_picture.superhero_id = superhero_id AND profile_picture.position = position;

END;

